import psycopg2

class Database:
    def __init__(self):
        # Configura aquí los datos de tu PostgreSQL local
        self.conexion = psycopg2.connect(
            host="localhost",
            database="inventario",
            user="postgres",
            password="12345"
        )
        self.cursor = self.conexion.cursor()

    def execute(self, query, params=None):
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            
            # Si es una consulta de lectura, devuelve las filas
            if query.strip().upper().startswith("SELECT"):
                return self.cursor.fetchall()
            
            # Si modifica la base de datos (INSERT, UPDATE, DELETE), guarda los cambios
            self.conexion.commit()
            return None
        except Exception as e:
            self.conexion.rollback()
            print(f"Error en la base de datos: {e}")
            raise e

    def close(self):
        self.cursor.close()
        self.conexion.close()
