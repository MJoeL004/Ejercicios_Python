from flask import Flask, jsonify, request
from bd import Database
import psycopg2

def conectar():
    conexion = psycopg2.connect(
        host="localhost",
        database="inventario",
        user="postgres",
        password="12345"
    )
    return conexion

app = Flask(__name__)

# ==========================
# LISTAR PRODUCTOS 
# ==========================
@app.route("/productos", methods=["GET"])
def listar_productos():
    db = Database()
    data = db.execute(
        "SELECT id, nombre, precio, activo FROM public.productos"
    )
    db.close()

    productos_formateados = []
    if data:
        for prod in data:
            productos_formateados.append({
                "id": prod[0],
                "nombre": prod[1],
                "precio": float(prod[2]) if prod[2] is not None else 0.0,
                "activo": prod[3],
                "campo_fecha": "2026-07-08 22:00:00"  
            })
    return jsonify(productos_formateados), 200

# ==========================
# 2. SELECT BY ID (Obtener por ID)
# ==========================
@app.route("/productos/<int:id>", methods=["GET"])
def obtener_producto(id):
    db = Database()
    
    # Agregamos campo_fecha::TEXT para cumplir con el Bonus de la rúbrica
    data = db.execute(
        "SELECT id, nombre, precio, activo, campo_fecha::TEXT FROM public.productos WHERE id=%s",
        (id,)
    )
    db.close()

    if data:
        prod = data[0]
        producto_formateado = {
            "id": prod[0],
            "nombre": prod[1],
            "precio": float(prod[2]) if prod[2] is not None else 0.0,
            "activo": prod[3],
            "campo_fecha": prod[4]  # Mapeo del Bonus
        }
        return jsonify(producto_formateado), 200
    
    return jsonify({"error": "Producto no encontrado"}), 404


# ==========================
# 3. CREATE (Crear producto) 
# ==========================
@app.route("/productos", methods=["POST"])
def crear_producto():
    data = request.json
    db = Database()

    db.execute(
        """
        INSERT INTO public.productos(nombre, precio, activo)
        VALUES (%s, %s, %s)
        """,
        (
            data["nombre"],
            data["precio"],
            data.get("activo", True)  
        )
    )
    db.close()

    return jsonify({
        "mensaje": "Producto creado exitosamente"
    }), 201


# ==========================
# 4. UPDATE (Actualizar producto) 
# ==========================
@app.route("/productos/<int:id>", methods=["PUT"])
def actualizar_producto(id):
    data = request.json
    db = Database()

    db.execute(
        """
        UPDATE public.productos
        SET nombre=%s,
            precio=%s,
            activo=%s
        WHERE id=%s
        """,
        (
            data["nombre"],
            data["precio"],
            data["activo"],
            id
        )
    )
    db.close()

    return jsonify({
        "mensaje": "Producto actualizado exitosamente"
    }), 200


# ==========================
# 5. DELETE (Eliminar producto) 
# ==========================
@app.route("/productos/<int:id>", methods=["DELETE"])
def eliminar_producto(id):
    db = Database()

    db.execute(
        "DELETE FROM public.productos WHERE id=%s",
        (id,)
    )
    db.close()

    return jsonify({
        "mensaje": "Producto eliminado exitosamente"
    }), 200


# ==========================
# INICIAR APLICACIÓN

if __name__ == "__main__":
    app.run(debug=True)
