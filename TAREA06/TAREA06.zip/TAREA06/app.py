from flask import Flask, jsonify
import psycopg2
from datetime import datetime

app = Flask(__name__)

# Configuración de la conexión a PostgreSQL
def get_db_connection():
    return psycopg2.connect(
        host="localhost",
        database="tarea06",        # Nombre de la base de datos creada
        user="postgres",           # Usuario por defecto de Postgres
        password="12345",   # REEMPLAZA CON TU CONTRASEÑA REAL
        port="5432"
    )

# Función para guardar en la base de datos qué ruta fue visitada
def registrar_ruta(nombre_dia):
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        # Insertar el día actual y la hora en Postgres
        cur.execute(
            "INSERT INTO bitacora (dia_visitado, fecha_hora) VALUES (%s, %s);",
            (nombre_dia, datetime.now())
        )
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error de conexión con PostgreSQL: {e}")
        return False

# ----- RUTAS DEL EJERCICIO -----

# Ruta para el Lunes
@app.route('/lunes', methods=['GET'])
def lunes():
    guardado = registrar_ruta("Lunes")
    return jsonify({
        "status": "Exitoso",
        "dia": "Lunes",
        "mensaje": "Inicio de la semana académica.",
        "registrado_en_db": guardado
    })

# Ruta para el Martes
@app.route('/martes', methods=['GET'])
def martes():
    guardado = registrar_ruta("Martes")
    return jsonify({
        "status": "Exitoso",
        "dia": "Martes",
        "mensaje": "Continuamos con las clases programadas.",
        "registrado_en_db": guardado
    })

# Ruta para el Miércoles
@app.route('/miercoles', methods=['GET'])
def miercoles():
    guardado = registrar_ruta("Miercoles")
    return jsonify({
        "status": "Exitoso",
        "dia": "Miércoles",
        "mensaje": "Mitad de semana de aprendizaje.",
        "registrado_en_db": guardado
    })

# Ruta para el Jueves
@app.route('/jueves', methods=['GET'])
def jueves():
    guardado = registrar_ruta("Jueves")
    return jsonify({
        "status": "Exitoso",
        "dia": "Jueves",
        "mensaje": "Última ruta de la semana indicada.",
        "registrado_en_db": guardado
    })

# Ruta raíz por comodidad
@app.route('/', methods=['GET'])
def index():
    return jsonify({
        "mensaje": "Servidor Flask activo en entorno virtual. Visita /lunes, /martes, /miercoles o /jueves."
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
