from flask import Flask, render_template
import psycopg2

app = Flask(__name__)

def obtener_conexion():
    return psycopg2.connect(
        # Si '127.0.0.1' falla, 'localhost' es la alternativa estándar
        host="localhost", 
        database="escuela",
        user="postgres",
        password="12345",
        port="5432" # Se agrega el puerto por defecto de PostgreSQL
    )

@app.route("/productos")
def productos():
    # Usamos 'try/finally' para asegurar que la conexión siempre se cierre, incluso si hay un error
    conexion = None
    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        
        cursor.execute("SELECT * FROM productos;")
        lista_productos = cursor.fetchall()
        
        cursor.close()
        return render_template("productos.html", productos=lista_productos)
        
    except Exception as e:
        return f"Error de conexión o base de datos: {e}", 500
        
    finally:
        if conexion:
            conexion.close()

if __name__ == "__main__":
    app.run(debug=True)
